#include <dlfcn.h>
#include <execinfo.h>
#include <fcntl.h>
#include <pthread.h>
#include <sched.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <new>
#include <vector>

namespace {
struct Range { unsigned long begin; unsigned long end; int cpu; };
struct Work {
    void *(*entry)(void *);
    void *argument;
    int cpu;
    long creator;
    unsigned long callsite;
};
bool splitMode() {
    const char *mode{std::getenv("ROLE_POLICY")};
    return mode && std::strcmp(mode, "split") == 0;
}
bool recordingProcess() {
    std::array<char, 1024> path{};
    const auto count{readlink("/proc/self/exe", path.data(), path.size() - 1)};
    return count > 0 && std::strstr(path.data(), "rk3576_recording_worker");
}
void logBinding(int cpu, long creator, unsigned long callsite) {
    cpu_set_t requested{};
    CPU_ZERO(&requested);
    int result{};
    if (splitMode() && cpu >= 0) {
        CPU_SET(cpu, &requested);
        result = pthread_setaffinity_np(pthread_self(), sizeof(requested), &requested);
    }
    cpu_set_t actual{};
    const int read_result{pthread_getaffinity_np(pthread_self(), sizeof(actual), &actual)};
    unsigned long mask{};
    for (int i{0}; i < 64; ++i) {
        if (CPU_ISSET(i, &actual)) { mask |= 1UL << i; }
    }
    std::array<char, 512> line{};
    const int size{std::snprintf(line.data(), line.size(),
        "pid=%d tid=%ld creator=%ld role_cpu=%d callsite=%lx split=%d rc=%d read_rc=%d mask=%lx running_cpu=%d\n",
        getpid(), syscall(SYS_gettid), creator, cpu, callsite, splitMode(), result, read_result, mask, sched_getcpu())};
    const char *path{std::getenv("ROLE_LOG")};
    if (path && size > 0 && size < static_cast<int>(line.size())) {
        const int fd{open(path, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0600)};
        if (fd >= 0) { const auto written{write(fd, line.data(), size)}; (void)written; close(fd); }
    }
    if (result || read_result) { _exit(120); }
}
const std::vector<Range> &ranges() {
    static const std::vector<Range> values{[] {
        std::vector<Range> result{};
        const char *path{std::getenv("ROLE_RANGES")};
        FILE *file{path ? std::fopen(path, "r") : nullptr};
        if (!file) { _exit(121); }
        std::array<char, 1024> line{};
        while (std::fgets(line.data(), line.size(), file)) {
            Range range{};
            if (std::sscanf(line.data(), "%lx %lx %d", &range.begin, &range.end, &range.cpu) == 3) {
                result.push_back(range);
            }
        }
        std::fclose(file);
        return result;
    }()};
    return values;
}
void *runWork(void *pointer) {
    std::unique_ptr<Work> work{static_cast<Work *>(pointer)};
    logBinding(work->cpu, work->creator, work->callsite);
    const auto entry{work->entry};
    void *argument{work->argument};
    work.reset();
    return entry(argument);
}
__attribute__((constructor)) void initialize() {
    // 只影响显式加载本诊断库的测试进程。未知库线程继承创建者的分配。
    logBinding(recordingProcess() ? 7 : 4, 0, 0);
}
} // namespace

extern "C" int pthread_create(pthread_t *thread, const pthread_attr_t *attributes,
                               void *(*entry)(void *), void *argument) noexcept {
    using Create = int (*)(pthread_t *, const pthread_attr_t *, void *(*)(void *), void *);
    static const auto real_create{reinterpret_cast<Create>(dlsym(RTLD_NEXT, "pthread_create"))};
    if (!real_create) { return ENOSYS; }
    try {
        int cpu{recordingProcess() ? 7 : -1};
        unsigned long callsite{};
        std::array<void *, 32> trace{};
        const int count{backtrace(trace.data(), trace.size())};
        for (int i{1}; i < count && cpu < 0; ++i) {
            Dl_info info{};
            if (!dladdr(trace[i], &info) || !info.dli_fname
                || !std::strstr(info.dli_fname, "drone_tracker_node")) { continue; }
            const auto offset{reinterpret_cast<unsigned long>(trace[i])
                              - reinterpret_cast<unsigned long>(info.dli_fbase) - 1};
            for (const auto &range : ranges()) {
                if (offset >= range.begin && offset < range.end) { cpu = range.cpu; callsite = offset; break; }
            }
        }
        auto work{std::make_unique<Work>(Work{entry, argument, cpu, syscall(SYS_gettid), callsite})};
        const int result{real_create(thread, attributes, runWork, work.get())};
        if (!result) { work.release(); }
        return result;
    } catch (...) { return EAGAIN; }
}
