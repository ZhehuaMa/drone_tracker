import json,re,math
from pathlib import Path
p=Path(__file__).parent
ctl=[json.loads(s) for s in (p/'controller.jsonl').read_text().splitlines() if s.startswith('{')]
results=[]
for case in ['split-1','audit-baseline','split-2']:
 start=next((x['wall'] for x in ctl if x.get('measurement_start')==case),None);end=next((x['wall'] for x in ctl if x.get('case_end')==case),None)
 if not start or not end or not (p/(case+'.log')).exists():continue
 stages={};windows=[];active=False
 for line in (p/(case+'.log')).read_text().splitlines():
  if 'OSD timing round=' in line:
   t=float(re.search(r'\[(\d+\.\d+)\]',line)[1]);w={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)};active=w['round']==1 and t-w['window_us']/1e6>=start+10 and t<=end
   if active:windows.append(w)
  elif active and 'new_video result=success' in line:
   for name,body in re.findall(r'(\w+)\{([^}]+)\}',line):
    d=dict(v.split('=',1) for v in body.split(','));n=int(d['count'])
    if not n:continue
    s=stages.setdefault(name,{'count':0,'sum':0,'max':0,'buckets':[0]*28});s['count']+=n;s['sum']+=float(d['mean'])*n;s['max']=max(s['max'],int(d['max']));s['buckets']=[a+b for a,b in zip(s['buckets'],map(int,d['buckets'].split(':')))]
 for s in stages.values():
  s['mean_ms']=s.pop('sum')/s['count']/1000;s['max_ms']=s.pop('max')/1000;cum=0
  for i,n in enumerate(s.pop('buckets')):
   cum+=n
   if cum>=math.ceil(s['count']*.95):s['p95_upper_ms']=2**i/1000;break
 sec=sum(w['window_us'] for w in windows)/1e6
 r={'case':case,'seconds':sec,'fps':sum(w['displayed'] for w in windows)/sec,'submit_fps':sum(w['submitted'] for w in windows)/sec,'stages':stages}
 resources=[x for x in ctl if x.get('case')==case and x.get('elapsed',0)>=10];r['busy']={}
 for a,b in zip(resources[0]['cpu'],resources[-1]['cpu']):
  d=[int(y)-int(x) for x,y in zip(a.split()[1:9],b.split()[1:9])];r['busy'][a.split()[0]]=100*(sum(d)-d[3]-d[4])/sum(d)
 roles=[dict(re.findall(r'(\w+)=([^ ]+)',line.strip())) for line in (p/(case+'-roles.log')).read_text().splitlines()]
 known=[d for d in roles if int(d['role_cpu'])>=0]
 r['role_counts']={str(cpu):sum(int(d['role_cpu'])==cpu for d in known) for cpu in [4,5,6,7]}
 r['binding_errors']=[d for d in roles if d['rc']!='0' or d['read_rc']!='0' or (d['split']=='1' and int(d['role_cpu'])>=0 and int(d['mask'],16)!=(1<<int(d['role_cpu'])))]
 tid_roles={d['tid']:int(d['role_cpu']) for d in known if d['split']=='1'}
 violations=[]
 for row in resources:
  for tid,info in row['threads'].items():
   if tid in tid_roles and info['affinity']!=[tid_roles[tid]]:violations.append({'tid':tid,'actual':info['affinity'],'expected':tid_roles[tid]})
 r['runtime_affinity_violations']=violations
 text=(p/(case+'.log')).read_text();r['init_count']=text.count('Tracker initialized');r['lost_count']=text.count('Target lost');r['final_camera']=[line for line in text.splitlines() if 'Camera final' in line];r['final_recording']=[line for line in text.splitlines() if 'phase=finished' in line]
 results.append(r);print(case,'fps',round(r['fps'],3),'submit',round(r['submit_fps'],3),'render',round(stages['render_total']['mean_ms'],3),'latency',round(stages['submit_to_display']['mean_ms'],3),'roles',r['role_counts'],'errors',len(r['binding_errors']),len(violations),'init',r['init_count'],'lost',r['lost_count'],'cpu',{k:round(v,1) for k,v in r['busy'].items()})
(p/'summary.json').write_text(json.dumps(results,indent=2))
