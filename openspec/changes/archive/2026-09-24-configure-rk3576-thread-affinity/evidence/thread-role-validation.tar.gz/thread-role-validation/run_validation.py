import os,time,json,subprocess,signal,sys
from pathlib import Path
import rclpy
from std_msgs.msg import Header
root=Path('/home/hzhy/thread-role-validation-20260924');mode=sys.argv[1] if len(sys.argv)>1 else 'smoke'
cases=[(mode,'split',8)] if mode.startswith('smoke') else [('split-1','split',75),('audit-baseline','audit',75),('split-2','split',75)]
rclpy.init();node=rclpy.create_node('role_affinity_validation');pub=node.create_publisher(Header,'/fpv/tracker_trigger',10)
def spin(seconds):
 end=time.monotonic()+seconds
 while time.monotonic()<end:rclpy.spin_once(node,timeout_sec=min(.2,max(0,end-time.monotonic())))
def send(cmd):
 m=Header();m.frame_id=cmd;m.stamp=node.get_clock().now().to_msg();pub.publish(m);spin(.2)
 print(json.dumps({'event':cmd,'wall':time.time()}),flush=True)
def descendants(pid):
 ids={pid}
 for _ in range(3):
  for p in Path('/proc').glob('[0-9]*'):
   try:
    if int(p.joinpath('stat').read_text().split(') ',1)[1].split()[1]) in ids:ids.add(int(p.name))
   except (FileNotFoundError,ProcessLookupError):pass
 return ids
proc=None
try:
 subprocess.run(['systemctl','stop','drone-tracker'],check=True)
 subprocess.run(['python3','/opt/drone_tracker/bin/prepare-display.py','/opt/drone_tracker/config/camera.yaml'],check=True)
 for label,policy,duration in cases:
  log=root/(label+'.log');role_log=root/(label+'-roles.log')
  if log.exists() or role_log.exists():raise RuntimeError('case artifacts already exist')
  args=['taskset','-c','4-7','env','LD_PRELOAD='+str(root/'role_affinity.so'),'ROLE_POLICY='+policy,'ROLE_LOG='+str(role_log),'ROLE_RANGES='+str(root/'roles.tsv'),'/opt/drone_tracker/current/lib/drone_tracker/drone_tracker_node','--ros-args','--params-file','/opt/drone_tracker/config/camera.yaml']
  with log.open('w') as f:proc=subprocess.Popen(args,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  deadline=time.monotonic()+30
  while time.monotonic()<deadline:
   if proc.poll() is not None:raise RuntimeError('node exited '+str(proc.returncode))
   spin(.2)
   if pub.get_subscription_count()>0 and 'OSD submitted=' in log.read_text():break
  else:raise RuntimeError('startup timed out')
  spin(1);print(json.dumps({'case_start':label,'policy':policy,'pid':proc.pid,'wall':time.time()}),flush=True)
  send('ON');trigger_deadline=time.monotonic()+15
  while 'Round starting' not in log.read_text():
   if time.monotonic()>trigger_deadline:raise RuntimeError('ON was not received')
   spin(1);send('ON')
  start=time.monotonic();print(json.dumps({'measurement_start':label,'wall':time.time()}),flush=True)
  while time.monotonic()-start<duration:
   if proc.poll() is not None:raise RuntimeError('node exited during run')
   row={'case':label,'elapsed':time.monotonic()-start,'wall':time.time(),'cpu':Path('/proc/stat').read_text().splitlines()[:9],'threads':{},'temp':{str(p):p.read_text().strip() for p in Path('/sys/class/thermal').glob('thermal_zone*/temp')}}
   for pid in descendants(proc.pid):
    for t in Path('/proc',str(pid),'task').glob('[0-9]*'):
     try:row['threads'][t.name]={'pid':pid,'affinity':sorted(os.sched_getaffinity(int(t.name))),'stat':(t/'stat').read_text()}
     except (FileNotFoundError,ProcessLookupError):pass
   print(json.dumps(row),flush=True);spin(1)
  send('OFF');print(json.dumps({'case_end':label,'wall':time.time()}),flush=True);spin(2)
  
  if label=='split-2':
   for cycle in range(3):
    previous=log.read_text().count('Round starting');send('ON');deadline=time.monotonic()+10
    while log.read_text().count('Round starting')<=previous:
     if time.monotonic()>deadline:raise RuntimeError('repeat ON was not received')
     spin(.5);send('ON')
    spin(5);send('OFF');spin(2);print(json.dumps({'restart_cycle':cycle+1,'case':label,'wall':time.time()}),flush=True)
  proc.send_signal(signal.SIGINT);proc.wait(timeout=20);print(json.dumps({'exit':proc.returncode,'case':label}),flush=True)
  if proc.returncode!=0:raise RuntimeError('nonzero exit')
  proc=None;spin(1)
finally:
 if proc and proc.poll() is None:
  send('OFF');spin(2);proc.send_signal(signal.SIGINT)
  try:proc.wait(timeout=20)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
 subprocess.run(['systemctl','start','drone-tracker'],check=True)
 print(json.dumps({'restored_service':True,'wall':time.time()}),flush=True)
 node.destroy_node();rclpy.shutdown()
