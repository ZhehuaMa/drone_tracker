import csv
import json
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parent
start = time.monotonic()
with (root / "logs/endurance.log").open("w") as console:
    process = subprocess.Popen(
        [str(root / "bin/nanotrackv3_search_direct"), str(root / "configs/endurance.yaml")],
        stdout=console, stderr=subprocess.STDOUT,
    )
    (root / "logs/endurance.pid").write_text(str(process.pid) + "\n")
    with (root / "logs/endurance-resources.csv").open("w") as samples:
        writer = csv.writer(samples)
        writer.writerow(["unix_seconds", "elapsed_seconds", "open_fds", "vmrss_kb",
                         "vmhwm_kb", "threads", "cpu_temp_millic"])
        while process.poll() is None:
            proc = Path("/proc") / str(process.pid)
            try:
                fields = dict(line.split(":", 1) for line in (proc / "status").read_text().splitlines())
                writer.writerow([
                    time.time(), time.monotonic() - start, len(list((proc / "fd").iterdir())),
                    fields.get("VmRSS", "").strip(), fields.get("VmHWM", "").strip(),
                    fields.get("Threads", "").strip(),
                    Path("/sys/class/thermal/thermal_zone0/temp").read_text().strip(),
                ])
                samples.flush()
            except FileNotFoundError:
                if process.poll() is None:
                    raise
            time.sleep(10)
    result = {"pid": process.pid, "exit_code": process.wait(),
              "elapsed_seconds": time.monotonic() - start,
              "device_memory_gap": "/sys/kernel/debug/rknpu/mm: Permission denied"}
    (root / "logs/endurance-result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)
    if result["exit_code"] != 0 or result["elapsed_seconds"] < 1800:
        raise SystemExit("Endurance acceptance failed: exit code or duration")
