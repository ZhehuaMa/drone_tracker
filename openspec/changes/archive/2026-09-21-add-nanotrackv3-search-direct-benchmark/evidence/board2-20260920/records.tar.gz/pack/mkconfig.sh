#!/bin/bash
set -eu
out=$1; detailed=$2; warmup=$3; maxu=$4; repeats=$5; interval=${6:-1000}
sed -e "s#^output:.*#output: \"/tmp/nanotrack-search-direct-acceptance-20260920/runs/$out\"#" \
    -e "s#^detailed_observation:.*#detailed_observation: $detailed#" \
    -e "s#^warmup_updates:.*#warmup_updates: $warmup#" \
    -e "s#^max_updates:.*#max_updates: $maxu#" \
    -e "s#^repeats:.*#repeats: $repeats#" \
    -e "s#^environment_interval_ms:.*#environment_interval_ms: $interval#" base.yaml > configs/$out.yaml
