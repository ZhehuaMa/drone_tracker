#!/bin/bash
# 持续回放并每 30 秒采样进程资源；只读取 /proc，不修改任何系统设置。
cd "$(dirname "$0")"
./bin/nanotrackv3_search_direct configs/endurance.yaml > logs/endurance.log 2>&1 &
pid=$!
echo "$pid" > logs/endurance.pid
echo 'unix_seconds,elapsed_seconds,open_fds,vmrss_kb,vmhwm_kb,threads,cpu_temp_millic' > logs/endurance-resources.csv
start=$(date +%s)
while kill -0 "$pid" 2>/dev/null; do
  now=$(date +%s)
  fds=$(ls /proc/$pid/fd 2>/dev/null | wc -l)
  rss=$(awk '/^VmRSS/{print $2}' /proc/$pid/status 2>/dev/null)
  hwm=$(awk '/^VmHWM/{print $2}' /proc/$pid/status 2>/dev/null)
  thr=$(awk '/^Threads/{print $2}' /proc/$pid/status 2>/dev/null)
  temp=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null)
  echo "$now,$((now-start)),$fds,${rss:-},${hwm:-},${thr:-},${temp:-}" >> logs/endurance-resources.csv
  sleep 30
done
wait "$pid"
echo "exit_code=$?" >> logs/endurance-resources.csv
