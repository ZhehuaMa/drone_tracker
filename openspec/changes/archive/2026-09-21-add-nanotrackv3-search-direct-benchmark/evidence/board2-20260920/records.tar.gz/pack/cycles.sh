#!/bin/bash
# 重复创建、初始化、reset、销毁，并在进程存活期间采样资源。
cd "$(dirname "$0")"
echo 'cycle,exit_code,max_open_fds,peak_rss_kb,initializations' > logs/cycles.csv
for i in $(seq 1 20); do
  sed "s#^output:.*#output: \"$PWD/runs/cycles/run-$i\"#" configs/cycle-template.yaml > configs/cycle.yaml
  ./bin/nanotrackv3_search_direct configs/cycle.yaml > logs/cycle-$i.log 2>&1 &
  pid=$!
  maxfd=0
  maxrss=0
  while kill -0 $pid 2>/dev/null; do
    fd=$(ls /proc/$pid/fd 2>/dev/null | wc -l)
    if [ -n "$fd" ] && [ "$fd" -gt "$maxfd" ]; then maxfd=$fd; fi
    rss=$(awk '/VmHWM/{print $2}' /proc/$pid/status 2>/dev/null)
    if [ -n "$rss" ] && [ "$rss" -gt "$maxrss" ]; then maxrss=$rss; fi
    sleep 0.2
  done
  wait $pid
  code=$?
  inits=$(python3 -c "import csv,sys;print(sum(1 for r in csv.DictReader(open('runs/cycles/run-$i/frames.csv')) if r['operation']=='init'))")
  echo "$i,$code,$maxfd,$maxrss,$inits" >> logs/cycles.csv
done
